# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Blog::Application.config.secret_token = '10fe677fba92ec3c5eb1422e346d61c2b5348a812ec44957e791ab07db0a5491480ded15ed3dd8f6c760d13c00eaa03227cfcbc1e97b289d4e0af9d741638fa9'
