# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '7055ec8f036eeb641b997eb8b2135b795cc6ca939efbcf5c25fc670e969b5465c2414671c6bd740789a43e22d282c1d889666eec826675a0312a0e91b71a2e9f';
